# watson_translator

## Editing the file

Its a markdown file in the repository.
